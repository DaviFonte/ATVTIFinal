CREATE DATABASE canes_solution;

USE canes_solution;

CREATE TABLE carrinho (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto VARCHAR(255) NOT NULL
);

CREATE TABLE mensagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    mensagem TEXT NOT NULL
);
