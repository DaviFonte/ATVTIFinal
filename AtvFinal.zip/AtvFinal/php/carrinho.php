<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'];
    $produto = $_POST['produto'];

    if ($acao == 'adicionar') {
        $sql = "INSERT INTO carrinho (produto) VALUES (:produto)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':produto', $produto);
        $stmt->execute();
        echo "Produto adicionado!";
    } elseif ($acao == 'remover') {
        $sql = "DELETE FROM carrinho WHERE produto = :produto LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':produto', $produto);
        $stmt->execute();
        echo "Produto removido!";
    }
}
?>
