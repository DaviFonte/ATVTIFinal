<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $mensagem = $_POST['mensagem'];

    $sql = "INSERT INTO mensagens (nome, mensagem) VALUES (:nome, :mensagem)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':mensagem', $mensagem);
    $stmt->execute();

    echo "Mensagem salva com sucesso!";
}
?>
